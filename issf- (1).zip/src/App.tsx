import { RangeConsole } from "./components/RangeConsole";
import { ScaledStage } from "./components/ScaledStage";
import { DiagnosticsScreen } from "./components/DiagnosticsScreen";

/**
 * ISSF 10m 공기권총·공기소총 사격 시뮬레이터
 *
 * `?diagnostics=1` 쿼리로 접속하면 채점/시리즈/음성 대기열 회귀 검사 화면이 열립니다.
 */
export default function App() {
  const diagnostics =
    new URLSearchParams(window.location.search).get("diagnostics") === "1";

  if (diagnostics) {
    return (
      <ScaledStage>
        <DiagnosticsScreen />
      </ScaledStage>
    );
  }

  return <RangeConsole />;
}
