import { pointFromRect, svgPointFromClient } from "../lib/geometry";
import {
  createSession,
  currentSeriesIndex,
  currentSeriesShots,
  isSessionOpen,
  sessionReducer,
  shotsForView,
} from "../lib/session";
import { SpeechQueue, pickVoice, scoreCallText } from "../lib/speech";
import { computeStats, cumulativeTotals } from "../lib/stats";
import { TARGET_SPECS, scoreShot, zoneOuterRadius } from "../lib/targetSpec";

export function assert(u, d) {
  if (!u) throw new Error(d);
}
export function assertEqual(u, d) {
  assert(Object.is(u, d), `Expected ${String(d)}, received ${String(u)}`);
}
export function assertClose(u, d) {
  assert(Math.abs(u - d) < 1e-5, `Expected ${d}, received ${u}`);
}
export const testConfig = (u = {}) => ({
  mode: "m60",
  discipline: "pistol",
  shots: 60,
  perShotSec: null,
  totalSec: null,
  scoring: "point",
  ...u,
});
export function fireShots(u, d, o = 0, s = 0) {
  let m = u;
  for (let h = 0; h < d; h++)
    m = sessionReducer(m, {
      type: "shot",
      x: o,
      y: s,
      now: h + 1,
    });
  return m;
}
export function runLogicTests() {
  const u = [],
    d = (o, s) => {
      try {
        (s(),
          u.push({
            name: o,
            passed: true,
          }));
      } catch (m) {
        u.push({
          name: o,
          passed: false,
          error: m instanceof Error ? m.message : String(m),
        });
      }
    };
  for (const o of ["pistol", "rifle"]) {
    for (const s of [10, 40, 60, 73, 100])
      d(`${o}: ${s}발 정확히 완료, 추가 착탄 차단`, () => {
        let h = createSession(
          testConfig({
            discipline: o,
            mode:
              s === 10
                ? "m10"
                : s === 40
                  ? "m40"
                  : s === 60
                    ? "m60"
                    : "practice",
            shots: s,
          }),
        );
        ((h = fireShots(h, s - 1)),
          assertEqual(h.phase, "live"),
          assertEqual(h.shots.length, s - 1),
          (h = sessionReducer(h, {
            type: "shot",
            x: 0,
            y: 0,
            now: s,
          })),
          assertEqual(h.phase, "finished"),
          assertEqual(h.shots.length, s),
          assertEqual(h.endReason, "shots"),
          assertEqual(isSessionOpen(h), false));
        const p = sessionReducer(h, {
          type: "shot",
          x: 0,
          y: 0,
          now: s + 1,
        });
        (assertEqual(p, h),
          assertEqual(h.totalDeadline, null),
          assertEqual(h.shotDeadline, null));
      });
    d(`${o}: 인쇄된 1~9점 구역과 착점 중심 채점 일치`, () => {
      const s = TARGET_SPECS[o];
      for (let m = 1; m <= 9; m++) {
        const h = (s.ringRadius(m) + s.ringRadius(m + 1)) / 2;
        for (const [p, N] of [
          [h, 0],
          [-h, 0],
          [0, h],
          [0, -h],
        ])
          assertEqual(scoreShot(s, p, N, "point").integer, m);
        assertEqual(scoreShot(s, s.ringRadius(m), 0, "point").integer, m);
      }
      assertEqual(scoreShot(s, 0, 0, "point").decimal, 10.9);
    });
    for (const s of ["point", "issf"])
      d(`${o}/${s}: 0.0~0.9 모든 소수점 구간`, () => {
        const m = TARGET_SPECS[o],
          h = zoneOuterRadius(m, 1, s),
          p = zoneOuterRadius(m, 0, s) - h;
        for (let N = 0; N < 10; N++) {
          const S = scoreShot(m, h + (p * (N + 0.5)) / 10, 0, s);
          (assertClose(S.decimal, (9 - N) / 10),
            assertEqual(S.integer, 0),
            assertEqual(S.inner, false));
        }
        assertEqual(scoreShot(m, h + p + 10, 0, s).decimal, 0);
      });
  }
  return (
    d("ISSF 소총 탄 반경은 한 번만 보정", () => {
      (assertEqual(scoreShot(TARGET_SPECS.rifle, 11.5, 0, "point").integer, 5),
        assertEqual(scoreShot(TARGET_SPECS.rifle, 11.5, 0, "issf").integer, 6),
        assertEqual(scoreShot(TARGET_SPECS.rifle, 2.5, 0, "issf").decimal, 10),
        assertEqual(
          scoreShot(TARGET_SPECS.rifle, 2.5001, 0, "issf").decimal,
          9.9,
        ));
    }),
    d("모드 지정 발수는 잘못 전달된 설정과 무관하게 적용", () => {
      (assertEqual(
        createSession(
          testConfig({
            mode: "m60",
            shots: null,
          }),
        ).config.shots,
        60,
      ),
        assertEqual(
          createSession(
            testConfig({
              mode: "m10",
              shots: 40,
            }),
          ).config.shots,
          10,
        ));
    }),
    d("첫 클릭부터 타이머, 카운트, 점수 기록", () => {
      const o = fireShots(
        createSession(
          testConfig({
            perShotSec: 20,
          }),
        ),
        1,
      );
      (assertEqual(o.startedAt, 1),
        assertEqual(o.shots.length, 1),
        assertEqual(o.shotDeadline, 20001),
        assertEqual(o.shots[0].index, 1));
    }),
    d("10발 직후에도 완료 시리즈 기록 유지, 11발에 다음 시리즈", () => {
      const o = fireShots(createSession(testConfig()), 10);
      (assertEqual(currentSeriesIndex(o), 0),
        assertEqual(currentSeriesShots(o).length, 10));
      const s = sessionReducer(o, {
        type: "shot",
        x: 0,
        y: 0,
        now: 11,
      });
      (assertEqual(currentSeriesIndex(s), 1),
        assertEqual(currentSeriesShots(s).length, 1),
        assertEqual(currentSeriesShots(s)[0].no, 1));
    }),
    d("전체 / 현재 시리즈 / 40샷 / 60샷 필터", () => {
      const o = fireShots(
        createSession(
          testConfig({
            mode: "practice",
            shots: null,
          }),
        ),
        73,
      );
      (assertEqual(shotsForView(o, "all").length, 73),
        assertEqual(shotsForView(o, "series").length, 3),
        assertEqual(shotsForView(o, "series", 2)[0].index, 21),
        assertEqual(shotsForView(o, "first40").length, 40),
        assertEqual(shotsForView(o, "first60").length, 60));
    }),
    d("40샷, 60샷, 합계는 첫 샷부터 실시간 누적", () => {
      const o = fireShots(createSession(testConfig()), 1);
      assertEqual(cumulativeTotals(o.shots, TARGET_SPECS.pistol).first40, 10);
      const s = fireShots(createSession(testConfig()), 41),
        m = cumulativeTotals(s.shots, TARGET_SPECS.pistol);
      (assertEqual(m.first40, 400),
        assertEqual(m.first60, 410),
        assertEqual(m.total, 410));
      const h = fireShots(
        createSession(
          testConfig({
            discipline: "rifle",
          }),
        ),
        60,
      );
      assertEqual(cumulativeTotals(h.shots, TARGET_SPECS.rifle).total, 654);
    }),
    d("지연된 틱에도 발당 시간 초과를 모두 기록하고 종료", () => {
      const o = createSession(
          testConfig({
            mode: "m10",
            shots: 10,
            perShotSec: 1,
          }),
        ),
        s = sessionReducer(o, {
          type: "begin",
          now: 0,
        }),
        m = sessionReducer(s, {
          type: "tick",
          now: 10001,
        });
      (assertEqual(m.phase, "finished"),
        assertEqual(m.shots.length, 10),
        assertEqual(m.shots.filter((h) => h.miss).length, 10),
        assertEqual(computeStats(m.shots).hitCount, 0),
        assertEqual(computeStats(m.shots).outer, 0));
    }),
    d("마지막 탄 제한시간 초과 시에도 결과 완료", () => {
      const o = fireShots(
          createSession(
            testConfig({
              mode: "m10",
              shots: 10,
              perShotSec: 1,
            }),
          ),
          9,
        ),
        s = sessionReducer(o, {
          type: "shot",
          x: 0,
          y: 0,
          now: 1010,
        });
      (assertEqual(s.phase, "finished"),
        assertEqual(s.shots.length, 10),
        assertEqual(s.shots[9].miss, true));
    }),
    d("전체 시간 종료는 늦은 클릭보다 우선", () => {
      const o = fireShots(
          createSession(
            testConfig({
              mode: "practice",
              shots: null,
              totalSec: 1,
            }),
          ),
          1,
        ),
        s = sessionReducer(o, {
          type: "shot",
          x: 0,
          y: 0,
          now: 1002,
        });
      (assertEqual(s.phase, "finished"),
        assertEqual(s.endReason, "total-time"),
        assertEqual(s.shots.length, 1));
    }),
    d("전체 리셋은 샷과 양쪽 타이머를 초기화", () => {
      const o = fireShots(
          createSession(
            testConfig({
              perShotSec: 20,
              totalSec: 120,
            }),
          ),
          15,
        ),
        s = createSession(o.config),
        m = sessionReducer(o, {
          type: "reset",
          session: s,
        });
      (assertEqual(m.phase, "ready"),
        assertEqual(m.shots.length, 0),
        assertEqual(m.startedAt, null),
        assertEqual(m.shotDeadline, null),
        assertEqual(m.totalDeadline, null),
        assert(m.id !== o.id, "Reset must create a new session identity"),
        assertEqual(m.config.shots, 60));
    }),
    d("CTC는 최외곽 두 착탄의 실제 중심간 거리", () => {
      let o = createSession(testConfig());
      for (const [s, m] of [
        [0, 0],
        [3, 0],
        [0, 4],
      ])
        o = sessionReducer(o, {
          type: "shot",
          x: s,
          y: m,
          now: 1,
        });
      (assertClose(computeStats(o.shots).ctc, 5),
        assertClose(computeStats(o.shots).outer, 9.5));
    }),
    d("비정상 좌표는 샷으로 기록하지 않음", () => {
      const o = createSession(testConfig());
      (assertEqual(
        sessionReducer(o, {
          type: "shot",
          x: NaN,
          y: 0,
          now: 1,
        }),
        o,
      ),
        assertEqual(
          sessionReducer(o, {
            type: "shot",
            x: 0,
            y: 1 / 0,
            now: 1,
          }),
          o,
        ));
    }),
    d("음성은 이전 점수 완료 후 다음 점수를 순서대로 호출", () => {
      const o = [],
        s = [];
      let m = 0;
      const h = new SpeechQueue({
        play: (p, N) => {
          (o.push(p), s.push(N));
        },
        cancel: () => {
          m++;
        },
      });
      (h.enqueue("9.1"),
        h.enqueue("9.2"),
        h.enqueue("10.9 X ten"),
        assertEqual(o.join(","), "9.1"),
        assertEqual(h.getSnapshot().pending, 2),
        s[0](),
        assertEqual(o.join(","), "9.1,9.2"),
        s[0](),
        assertEqual(o.length, 2),
        s[1](),
        assertEqual(o.join(","), "9.1,9.2,10.9 X ten"),
        s[2](),
        assertEqual(h.getSnapshot().speaking, false),
        assertEqual(m, 0));
    }),
    d("음성 리셋 후 이전 완료 이벤트가 새 대기열을 건드리지 않음", () => {
      const o = [],
        s = [],
        m = new SpeechQueue({
          play: (h, p) => {
            (o.push(h), s.push(p));
          },
          cancel: () => {},
        });
      (m.enqueue("old"),
        m.enqueue("discarded"),
        m.clear(),
        m.enqueue("new"),
        s[0](),
        assertEqual(o.join(","), "old,new"),
        assertEqual(m.getSnapshot().speaking, true),
        s[1](),
        assertEqual(m.getSnapshot().speaking, false));
    }),
    d("0.0점과 X ten 음성 문구", () => {
      (assertEqual(scoreCallText(0, false), "zero point zero."),
        assertEqual(scoreCallText(0.9, false), "zero point nine."),
        assertEqual(scoreCallText(10.9, true), "ten point nine. X ten."),
        assertEqual(scoreCallText(10, false, true), "ten."));
    }),
    d("female 문자열을 male 음성으로 잘못 매칭하지 않음", () => {
      const o = [
        {
          name: "English Female",
          lang: "en-US",
        },
        {
          name: "Daniel",
          lang: "en-GB",
        },
      ];
      (assertEqual(pickVoice(o, "male")?.name, "Daniel"),
        assertEqual(pickVoice(o, "female")?.name, "English Female"));
    }),
    d("가로/세로 여백 및 축소 비율을 반영한 좌표", () => {
      for (const o of [0.5, 1, 1.2, 2]) {
        const s = {
            left: 100,
            top: 80,
            width: 800 * o,
            height: 600 * o,
          },
          m = pointFromRect(s, 40.8, 100 + 400 * o, 80 + 300 * o);
        (assertClose(m.x, 0), assertClose(m.y, 0));
        const h = pointFromRect(
          s,
          40.8,
          100 + 400 * o + (11.5 / 81.6) * 600 * o,
          80 + 300 * o,
        );
        (assertClose(h.x, 11.5), assertClose(h.y, 0));
      }
    }),
    u
  );
}
export function runSvgTransformTest() {
  const u = "실제 SVG / CSS 변환에서 소총 5점 위치 역변환",
    d = document.createElement("div");
  d.style.cssText =
    "position:fixed;left:23px;top:17px;width:500px;height:300px;transform:scale(0.73);transform-origin:0 0;visibility:hidden;pointer-events:none";
  const o = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  (o.setAttribute("width", "500"),
    o.setAttribute("height", "300"),
    o.setAttribute("viewBox", "-40.8 -40.8 81.6 81.6"));
  const s = document.createElementNS("http://www.w3.org/2000/svg", "circle");
  (s.setAttribute("cx", "11.5"),
    s.setAttribute("cy", "0"),
    s.setAttribute("r", "0.1"),
    o.appendChild(s),
    d.appendChild(o),
    document.body.appendChild(d));
  try {
    const m = s.getBoundingClientRect(),
      h = svgPointFromClient(
        o,
        40.8,
        m.left + m.width / 2,
        m.top + m.height / 2,
      );
    return (
      assert(Math.abs(h.x - 11.5) < 0.001, "SVG screen transform x mismatch"),
      assert(Math.abs(h.y) < 0.001, "SVG screen transform y mismatch"),
      assertEqual(scoreShot(TARGET_SPECS.rifle, h.x, h.y, "point").integer, 5),
      {
        name: u,
        passed: true,
      }
    );
  } catch (m) {
    return {
      name: u,
      passed: false,
      error: m instanceof Error ? m.message : String(m),
    };
  } finally {
    d.remove();
  }
}
