/**
 * 25m 영점표적지(M16A1) — 세로형 격자 실루엣 표적.
 * 텍스트·좌표 숫자 없이 격자와 인체 실루엣, 백색 조준원만 표시합니다.
 */
export function ZeroingFace({ spec }) {
  const cell = spec.gridCell,
    gx = spec.gridX * cell,
    gt = spec.gridTop * cell,
    gb = spec.gridBottom * cell,
    lines = [];
  for (let i = -spec.gridX; i <= spec.gridX; i++) {
    const v = i * cell,
      axis = i === 0;
    lines.push(
      <line
        key={`v${i}`}
        x1={v}
        y1={-gt}
        x2={v}
        y2={gb}
        stroke={axis ? "#8d939c" : "#bcc2ca"}
        strokeWidth={axis ? 0.8 : 0.42}
      />,
    );
  }
  for (let i = -spec.gridTop; i <= spec.gridBottom; i++) {
    const v = i * cell,
      axis = i === 0;
    lines.push(
      <line
        key={`h${i}`}
        x1={-gx}
        y1={v}
        x2={gx}
        y2={v}
        stroke={axis ? "#8d939c" : "#bcc2ca"}
        strokeWidth={axis ? 0.8 : 0.42}
      />,
    );
  }
  return (
    <g>
      {/* 표적지 본체 (공백 없이 격자 전체를 꽉 채움) */}
      <rect
        x={-gx}
        y={-gt}
        width={gx * 2}
        height={gt + gb}
        fill="#fbfaf6"
      />
      {lines}
      <rect
        x={-gx}
        y={-gt}
        width={gx * 2}
        height={gt + gb}
        fill="none"
        stroke="#23262b"
        strokeWidth={0.9}
      />
      {/* 인체 실루엣: 머리 + 몸통 (격자 칸 기준 비율) */}
      <path
        d={`M ${-cell * 1.5} ${-cell * 3} L ${-cell * 1.5} ${-cell * 5.3} A ${cell * 1.5} ${cell * 1.5} 0 0 1 ${cell * 1.5} ${-cell * 5.3} L ${cell * 1.5} ${-cell * 3} Z`}
        fill="#131313"
      />
      <rect
        x={-cell * 3.6}
        y={-cell * 3}
        width={cell * 7.2}
        height={cell * 8.5}
        fill="#131313"
      />
      {/* 백색 조준원 + 중심 표식 */}
      <circle cx={0} cy={cell * 0.6} r={cell * 2.7} fill="#fbfaf6" />
      <rect
        x={-cell * 1.1}
        y={-cell * 1.9}
        width={cell * 2.2}
        height={cell * 2.5}
        fill="#131313"
      />
      <circle cx={0} cy={0} r={cell * 0.3} fill="#131313" />
    </g>
  );
}

export function TargetFace({ spec, plain = false }) {
  if (spec.zeroing) return <ZeroingFace spec={spec} plain={plain} />;
  const o = spec.cardSize / 2,
    s = Array.from(
      {
        length: 10,
      },
      (m, h) => h + 1,
    );
  return (
    <g>
      <rect
        x={-o}
        y={-o}
        width={spec.cardSize}
        height={spec.cardSize}
        fill="#fbfaf6"
      />
      <circle r={spec.blackRadius} fill="#111111" />
      {s.map((m) => {
        const h = spec.ringRadius(m);
        if (Math.abs(h - spec.blackRadius) < 0.01) return null;
        if (m === 10 && spec.tenIsDot)
          return <circle key={m} r={h} fill="#ffffff" />;
        const p = h < spec.blackRadius;
        return (
          <circle
            key={m}
            r={h}
            fill="none"
            stroke={p ? "#ffffff" : "#141414"}
            strokeWidth={spec.ringStroke}
            opacity={p ? 0.95 : 0.55}
          />
        );
      })}
      {spec.innerTenRadius !== null && (
        <circle
          r={spec.innerTenRadius}
          fill="none"
          stroke="#ffffff"
          strokeWidth={spec.ringStroke}
          opacity={0.95}
        />
      )}
      {!plain &&
        spec.numberRings.map((m) => {
          const h = (spec.ringRadius(m) + spec.ringRadius(m + 1)) / 2,
            p = spec.whiteNumberRings.includes(m);
          return [
            [0, -h],
            [0, h],
            [-h, 0],
            [h, 0],
          ].map(([N, S], x) => (
            <text
              key={`${m}-${x}`}
              x={N}
              y={S}
              fill={p ? "#ffffff" : "#141414"}
              fontSize={spec.numberFontSize}
              fontFamily="Helvetica, Arial, sans-serif"
              fontWeight={500}
              textAnchor="middle"
              dominantBaseline="central"
              opacity={p ? 0.92 : 0.75}
            >
              {m}
            </text>
          ));
        })}
    </g>
  );
}
