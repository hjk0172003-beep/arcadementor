import React from "react";
import { speechQueue, speechSupported } from "../lib/speech";

export function SpeechStatus({ voice }) {
  const d = React.useSyncExternalStore(
      speechQueue.subscribe,
      speechQueue.getSnapshot,
      speechQueue.getSnapshot,
    ),
    o = voice !== "off",
    s = o
      ? speechSupported()
        ? d.error
          ? "음성 엔진 확인 필요"
          : d.speaking
            ? "점수 안내 중"
            : "점수 음성 대기"
        : "음성 미지원"
      : "음성 안내 꺼짐";
  return (
    <span
      className={`speech-status ${d.speaking ? "is-speaking" : ""}`}
      title={
        d.error ?? "새 착탄이 들어와도 현재 점수 안내를 끝까지 재생합니다."
      }
    >
      <span className="speech-status-dot" />
      {s}
      {o && d.pending > 0 && (
        <strong>
          +{d.pending}
          {" 대기"}
        </strong>
      )}
    </span>
  );
}
