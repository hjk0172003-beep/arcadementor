import React from "react";
import { ShotMarks } from "./ShotMarks";
import { TargetFace } from "./TargetFace";
import {
  clearRecords,
  deleteRecord,
  formatSavedAt,
  loadRecords,
} from "../lib/records";
import { computeStats, fixed, formatTotal } from "../lib/stats";
import { MATCH_MODES, TARGET_SPECS } from "../lib/targetSpec";

const SPEEDS = [1, 2, 4];

/** 저장된 기록을 한 발씩 재생하는 리플레이 플레이어 */
function ReplayPlayer({ record }) {
  const spec = {
      ...TARGET_SPECS[record.discipline],
      decimalTotals: record.decimalTotals,
    },
    total = record.shots.length,
    [cursor, setCursor] = React.useState(total),
    [playing, setPlaying] = React.useState(false),
    [speed, setSpeed] = React.useState(2),
    timer = React.useRef(null);

  // 기록이 바뀌면 처음 상태로
  React.useEffect(() => {
    setCursor(total);
    setPlaying(false);
  }, [record.id, total]);

  // 재생 루프: 저장된 실제 사격 간격(dt)을 배속으로 재현
  React.useEffect(() => {
    if (!playing) return;
    if (cursor >= total) {
      setPlaying(false);
      return;
    }
    const cur = record.shots[cursor],
      prev = cursor > 0 ? record.shots[cursor - 1] : null,
      gap = prev ? Math.max(0, cur.dt - prev.dt) : 0,
      wait = Math.min(2500, Math.max(220, gap || 700)) / speed;
    timer.current = window.setTimeout(() => setCursor((c) => c + 1), wait);
    return () => window.clearTimeout(timer.current);
  }, [playing, cursor, total, speed, record]);

  const shown = record.shots.slice(0, cursor),
    stats = computeStats(shown),
    last = shown[shown.length - 1] ?? null,
    zeroing = !!spec.zeroing,
    vb = zeroing
      ? `${-spec.cardWidth / 2} ${-spec.gridTop * spec.gridCell} ${spec.cardWidth} ${spec.cardHeight}`
      : `${-spec.cardSize * 0.51} ${-spec.cardSize * 0.51} ${spec.cardSize * 1.02} ${spec.cardSize * 1.02}`,
    runningTotal = shown.reduce(
      (acc, s) => acc + (record.decimalTotals ? s.decimal : s.integer),
      0,
    );

  const play = () => {
    if (cursor >= total) setCursor(0);
    setPlaying(true);
  };

  return (
    <div className="replay-player">
      <div className="replay-stage">
        <svg viewBox={vb} className={zeroing ? "is-zeroing" : ""}>
          <TargetFace spec={spec} />
          <ShotMarks
            shots={shown}
            spec={spec}
            stroke={zeroing ? 0.7 : spec.cardSize * 0.006}
            lastId={last?.id ?? null}
            numbers
            numberField="index"
            fontSize={zeroing ? 6 : spec.cardSize * 0.026}
          />
        </svg>
      </div>
      <div className="replay-controls">
        <button
          className="console-button primary"
          onClick={() => (playing ? setPlaying(false) : play())}
        >
          {playing ? "⏸ 일시정지" : cursor >= total ? "▶ 다시 재생" : "▶ 재생"}
        </button>
        <button
          className="console-button"
          onClick={() => {
            setPlaying(false);
            setCursor(0);
          }}
        >
          ⏮ 처음
        </button>
        <button
          className="console-button"
          onClick={() => {
            setPlaying(false);
            setCursor((c) => Math.max(0, c - 1));
          }}
        >
          ◀ 이전
        </button>
        <button
          className="console-button"
          onClick={() => {
            setPlaying(false);
            setCursor((c) => Math.min(total, c + 1));
          }}
        >
          다음 ▶
        </button>
        <div className="replay-speed" aria-label="재생 속도">
          {SPEEDS.map((v) => (
            <button
              key={v}
              aria-pressed={speed === v}
              onClick={() => setSpeed(v)}
            >
              {v}×
            </button>
          ))}
        </div>
      </div>
      <input
        className="replay-range"
        type="range"
        min={0}
        max={total}
        value={cursor}
        aria-label="리플레이 위치"
        onChange={(e) => {
          setPlaying(false);
          setCursor(Number(e.target.value));
        }}
      />
      <div className="replay-readout">
        <div>
          <span>진행</span>
          <strong>
            {cursor}
            <small>{` / ${total} 발`}</small>
          </strong>
        </div>
        <div>
          <span>현재 샷</span>
          <strong>
            {last
              ? last.miss
                ? "T/O"
                : record.decimalTotals
                  ? last.decimal.toFixed(1)
                  : String(last.integer)
              : "--"}
          </strong>
        </div>
        <div>
          <span>누적 점수</span>
          <strong>{formatTotal(runningTotal, record.decimalTotals)}</strong>
        </div>
        <div>
          <span>CTC</span>
          <strong>
            {stats.hitCount > 1 ? fixed(stats.ctc) : "--"}
            <small>{" mm"}</small>
          </strong>
        </div>
      </div>
    </div>
  );
}

export function RecordsScreen({ onBack, highlightId = null }) {
  const [records, setRecords] = React.useState(() => loadRecords()),
    [selectedId, setSelectedId] = React.useState(
      highlightId ?? records[0]?.id ?? null,
    );
  const selected =
    records.find((r) => r.id === selectedId) ?? records[0] ?? null;

  return (
    <div className="records-screen">
      <header className="records-header">
        <div>
          <span className="eyebrow">PERSONAL RECORDS</span>
          <h1>개인 기록</h1>
          <p>저장한 사격 기록을 다시 보고 영상처럼 재생할 수 있습니다.</p>
        </div>
        <div className="flex gap-[10px]">
          {records.length > 0 && (
            <button
              className="console-button"
              onClick={() => {
                setRecords(clearRecords());
                setSelectedId(null);
              }}
            >
              전체 삭제
            </button>
          )}
          <button className="console-button primary" onClick={onBack}>
            메뉴로
          </button>
        </div>
      </header>
      {records.length === 0 ? (
        <div className="records-empty">
          <strong>저장된 기록이 없습니다.</strong>
          <span>
            사격을 마치고 결과 화면에서 <b>기록 저장</b>을 누르면 이곳에
            보관됩니다.
          </span>
        </div>
      ) : (
        <div className="records-body">
          <ul className="records-list" aria-label="기록 목록">
            {records.map((r) => {
              const on = selected?.id === r.id,
                mode = MATCH_MODES.find((m) => m.id === r.mode);
              return (
                <li key={r.id}>
                  <button
                    className={`record-item ${on ? "is-selected" : ""}`}
                    aria-pressed={on}
                    onClick={() => setSelectedId(r.id)}
                  >
                    <span className="record-item-name">{r.name}</span>
                    <span className="record-item-meta">
                      {r.disciplineLabel}
                      {" · "}
                      {mode?.title ?? r.mode}
                      {" · "}
                      {r.shotCount}발
                    </span>
                    <span className="record-item-foot">
                      <span>{formatSavedAt(r.savedAt)}</span>
                      <strong>
                        {formatTotal(r.total, r.decimalTotals)}
                        <small>{r.discipline === "zero" ? "" : " 점"}</small>
                      </strong>
                    </span>
                  </button>
                  <button
                    className="record-delete"
                    aria-label={`${r.name} 삭제`}
                    onClick={() => {
                      const next = deleteRecord(r.id);
                      setRecords(next);
                      if (selectedId === r.id)
                        setSelectedId(next[0]?.id ?? null);
                    }}
                  >
                    ✕
                  </button>
                </li>
              );
            })}
          </ul>
          <section className="records-detail" aria-label="기록 리플레이">
            {selected && (
              <>
                <div className="records-detail-head">
                  <div>
                    <strong>{selected.name}</strong>
                    <span>
                      {selected.disciplineLabel}
                      {" · "}
                      {MATCH_MODES.find((m) => m.id === selected.mode)?.title ??
                        selected.mode}
                      {" · "}
                      {formatSavedAt(selected.savedAt)}
                    </span>
                  </div>
                  <div className="records-detail-total">
                    <span>합계</span>
                    <strong>
                      {formatTotal(selected.total, selected.decimalTotals)}
                    </strong>
                  </div>
                </div>
                <ReplayPlayer record={selected} />
              </>
            )}
          </section>
        </div>
      )}
    </div>
  );
}
