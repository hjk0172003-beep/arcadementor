import React from "react";
import { Dialog } from "./Dialog";
import { ShotMarks } from "./ShotMarks";
import { SpeechStatus } from "./SpeechStatus";
import { TargetFace } from "./TargetFace";

import { seriesShots } from "../lib/session";
import {
  computeStats,
  cumulativeTotals,
  fixed,
  formatTotal,
  seriesTotal,
} from "../lib/stats";
import { MATCH_MODES } from "../lib/targetSpec";

export function ResultsSheet({
  session,
  spec,
  stats,
  voice,
  onReview,
  onRestart,
  onMenu,
  onSaveRecord,
}) {
  const N = cumulativeTotals(session.shots, spec),
    S = session.shots.length,
    x = MATCH_MODES.find((F) => F.id === session.config.mode),
    H = Math.max(1, Math.ceil(S / 10)),
    C = spec.cardSize * 0.51,
    Y =
      session.endReason === "total-time"
        ? "전체 제한시간 종료"
        : session.endReason === "manual"
          ? "사용자 종료"
          : "지정 발수 완료";
  const [recordName, setRecordName] = React.useState(""),
    [selected, setSelected] = React.useState("all"),
    seriesIndex = selected === "all" ? null : Math.min(selected, H - 1),
    viewShots =
      seriesIndex === null ? session.shots : seriesShots(session, seriesIndex),
    viewStats = seriesIndex === null ? stats : computeStats(viewShots),
    zeroing = !!spec.zeroing,
    // 영점 표적은 세로형이므로 실제 카드 비율의 viewBox를 사용합니다.
    viewBox = zeroing
      ? `${-spec.cardWidth / 2} ${-spec.gridTop * spec.gridCell} ${spec.cardWidth} ${spec.cardHeight}`
      : `${-C} ${-C} ${C * 2} ${C * 2}`;
  return (
    <Dialog
      labelId="results-title"
      onClose={() => onReview()}
      className="summary-sheet"
    >
      <header className="summary-header">
        <div>
          <span className="eyebrow">SESSION COMPLETE</span>
          <h1 id="results-title">사격 결과</h1>
          <p>
            {spec.label} <span>·</span> {x.title}
          </p>
        </div>
        <div className="summary-score">
          <span>{zeroing ? "총 탄착" : "최종 합계"}</span>
          <strong data-testid="final-total">
            {zeroing ? (
              <>
                {stats.hitCount}
                <small>발</small>
              </>
            ) : (
              <>
                {formatTotal(N.total, spec.decimalTotals)}
                <small>점</small>
              </>
            )}
          </strong>
          <span>
            {zeroing ? "점수 미채점 · " : ""}
            {Y}
            {" · "}
            {S}
            {zeroing ? "" : ` / ${session.config.shots ?? S}`}
            {" 샷"}
          </span>
        </div>
      </header>
      <div className="summary-content">
        <section className="summary-target-column" aria-label="탄착 확인">
          <div className="summary-section-label">
            {seriesIndex === null
              ? "전체 탄착 "
              : `${seriesIndex + 1}시리즈 탄착 `}
            <span>{viewStats.hitCount}발 명중 기록</span>
          </div>
          <div className="summary-series-tabs" aria-label="시리즈 선택">
            <button
              onClick={() => setSelected("all")}
              aria-pressed={seriesIndex === null}
            >
              전체
            </button>
            {Array.from(
              {
                length: H,
              },
              (F, ct) => (
                <button
                  key={ct}
                  onClick={() => setSelected(ct)}
                  aria-pressed={seriesIndex === ct}
                >
                  {String(ct + 1).padStart(2, "0")}
                </button>
              ),
            )}
          </div>
          <svg
            viewBox={viewBox}
            className={`summary-target ${zeroing ? "is-zeroing" : ""}`}
          >
            <TargetFace spec={spec} />
            <ShotMarks
              shots={viewShots}
              spec={spec}
              stroke={zeroing ? 0.7 : spec.cardSize * 0.005}
              numbers
              numberField={seriesIndex === null ? "index" : "no"}
              fontSize={zeroing ? 6 : spec.cardSize * 0.022}
            />
          </svg>
          <div className="summary-ctc">
            <span>
              {"CTC "}
              <small>
                {seriesIndex === null
                  ? "전체 탄착 중심 간 거리"
                  : `${seriesIndex + 1}시리즈 탄착 중심 간 거리`}
              </small>
            </span>
            <strong>
              {viewStats.hitCount > 1 ? fixed(viewStats.ctc) : "--"}
              <small>{" mm"}</small>
            </strong>
          </div>
          <p className="summary-note">
            {zeroing ? (
              "영점 모드는 점수 채점 없이 탄착 위치만 기록합니다."
            ) : (
              <>
                시간 초과 기록은 탄착군 계산에서 제외됩니다.
                <br />
                0.1~0.9점은 게임용 확장 점수입니다.
              </>
            )}
          </p>
        </section>
        <section className="summary-data" aria-label="시리즈별 결과">
          <div className="summary-statistics">
            <div>
              <span>총 탄착</span>
              <strong>
                {stats.hitCount}
                <small>{" 발"}</small>
              </strong>
            </div>
            {!zeroing && (
              <>
                <div>
                  <span>평균 점수</span>
                  <strong>
                    {stats.n ? stats.avgDecimal.toFixed(2) : "0.00"}
                  </strong>
                </div>
                <div>
                  <span>엑스텐</span>
                  <strong>
                    {stats.inners}
                    <small>{" X"}</small>
                  </strong>
                </div>
                <div>
                  <span>최고 / 최저</span>
                  <strong>
                    {stats.best.toFixed(1)}
                    <small>
                      {" / "}
                      {stats.worst.toFixed(1)}
                    </small>
                  </strong>
                </div>
              </>
            )}
            <div>
              <span>시간 초과 샷</span>
              <strong>
                {S - stats.hitCount}
                <small>{" 발"}</small>
              </strong>
            </div>
          </div>
          <div className="summary-section-label">
            시리즈 기록
            <span>
              {zeroing
                ? "탄착 기록"
                : spec.decimalTotals
                  ? "소수점 합계"
                  : "정수 합계"}
              {" · 시리즈를 눌러 탄착 확인"}
            </span>
          </div>
          <div className="summary-records">
            <table>
              <thead>
                <tr>
                  <th>시리즈</th>
                  {Array.from(
                    {
                      length: 10,
                    },
                    (F, ct) => (
                      <th key={ct}>{ct + 1}</th>
                    ),
                  )}
                  <th>합계</th>
                  <th>CTC</th>
                </tr>
              </thead>
              <tbody>
                {Array.from(
                  {
                    length: H,
                  },
                  (F, ct) => {
                    const Z = seriesShots(session, ct),
                      k = computeStats(Z);
                    return (
                      <tr key={ct}>
                        <th>
                          <button
                            onClick={() => setSelected(ct)}
                            aria-pressed={seriesIndex === ct}
                            title={`${ct + 1}시리즈 탄착 보기`}
                          >
                            {String(ct + 1).padStart(2, "0")}
                            {" ↗"}
                          </button>
                        </th>
                        {Array.from(
                          {
                            length: 10,
                          },
                          (yt, Ot) => (
                            <td
                              key={Ot}
                              className={Z[Ot]?.inner ? "is-xten" : ""}
                            >
                              {Z[Ot]
                                ? zeroing
                                  ? "●"
                                  : Z[Ot].decimal.toFixed(1)
                                : "-"}
                            </td>
                          ),
                        )}
                        <td className="summary-series-total">
                          {zeroing
                            ? `${Z.length}발`
                            : formatTotal(
                                seriesTotal(Z, spec),
                                spec.decimalTotals,
                              )}
                        </td>
                        <td>{k.hitCount > 1 ? fixed(k.ctc) : "-"}</td>
                      </tr>
                    );
                  },
                )}
              </tbody>
            </table>
          </div>
          {!zeroing && (
            <div className="summary-checkpoints">
              <div>
                <span>40샷 합계</span>
                <strong>{formatTotal(N.first40, spec.decimalTotals)}</strong>
                <small>1~40번 샷 누적</small>
              </div>
              <div>
                <span>60샷 합계</span>
                <strong>{formatTotal(N.first60, spec.decimalTotals)}</strong>
                <small>1~60번 샷 누적</small>
              </div>
              <div>
                <span>합계</span>
                <strong>{formatTotal(N.total, spec.decimalTotals)}</strong>
                <small>
                  {"전체 "}
                  {S}발 누적
                </small>
              </div>
            </div>
          )}
          {session.config.shots !== null && S < session.config.shots && (
            <p className="summary-note">
              {"미사격 "}
              {session.config.shots - S}발은 점수에 가산되지 않습니다.
            </p>
          )}
        </section>
      </div>
      <footer className="summary-footer">
        <SpeechStatus voice={voice} />
        <div className="ml-auto flex items-center gap-[10px]">
          <input
            className="record-name-input"
            value={recordName}
            placeholder="기록 이름 (예: 홍길동 1회차)"
            aria-label="기록 이름"
            maxLength={24}
            onChange={(e) => setRecordName(e.target.value)}
          />
          <button
            className="console-button"
            onClick={() =>
              onSaveRecord?.({
                name: recordName,
                total: N.total,
              })
            }
          >
            기록 저장
          </button>
          <button className="console-button" onClick={() => onReview()}>
            탄착 확인
          </button>
          <button className="console-button" onClick={onMenu}>
            메뉴
          </button>
          <button className="console-button primary" onClick={onRestart}>
            다시 사격
          </button>
        </div>
      </footer>
    </Dialog>
  );
}
