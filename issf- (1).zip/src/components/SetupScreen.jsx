import { cn } from "../utils/cn";
import { TargetFace } from "./TargetFace";
import {
  VOICE_OPTIONS,
  clearSpeech,
  scoreCallParts,
  speakScore,
} from "../lib/speech";
import * as targetSpec from "../lib/targetSpec";
import { playImpactSound } from "../lib/audio";
const { MATCH_MODES, TARGET_SPECS } = targetSpec;

export const PRACTICE_SHOT_OPTIONS = [10, 20, 40, 60, 100, null],
  TOTAL_SEC_STEP = 30,
  TOTAL_SEC_MAX = 120 * 60,
  PER_SHOT_SEC_STEP = 5,
  PER_SHOT_SEC_MAX = 180;

export function formatSeconds(sec) {
  if (sec === null) return "없음";
  const m = Math.floor(sec / 60),
    s = sec % 60;
  if (m === 0) return `${s}초`;
  // 30초 단위를 명확히 보여주기 위해 분 단위에도 초를 항상 표기합니다.
  return `${m}분 ${String(s).padStart(2, "0")}초`;
}

/** 단위(step)만큼 늘리고 줄이는 시간 선택기 */
export function StepRow({ label, value, step, max, onChange }) {
  const stepBtn =
    "w-[48px] shrink-0 border-r border-white/10 py-[9px] font-mono text-[17px] transition-colors last:border-r-0 disabled:opacity-30";
  return (
    <div className="flex items-center gap-[10px]">
      <span className="w-[118px] shrink-0 text-[13px] font-semibold tracking-[0.06em] text-slate-300">
        {label}
        <small className="ml-[5px] font-normal text-slate-500">{step}초</small>
      </span>
      <div className="flex flex-1 overflow-hidden rounded-[2px] border border-white/10">
        <button
          onClick={() => onChange(null)}
          className={cn(
            "w-[68px] shrink-0 border-r border-white/10 py-[9px] font-mono text-[14px] transition-colors",
            value === null
              ? "bg-amber-400 font-bold text-[#0b0e13]"
              : "bg-white/[0.03] text-slate-300 hover:bg-white/[0.08]",
          )}
        >
          없음
        </button>
        <button
          onClick={() =>
            onChange(
              value === null ? null : value - step <= 0 ? null : value - step,
            )
          }
          disabled={value === null}
          className={cn(
            stepBtn,
            "bg-white/[0.03] text-slate-300 hover:bg-white/[0.08]",
          )}
          aria-label={`${step}초 줄이기`}
        >
          −
        </button>
        <div
          className={cn(
            "flex flex-1 items-center justify-center border-r border-white/10 py-[9px] font-mono text-[15px] tabular-nums",
            value === null
              ? "text-slate-500"
              : "bg-amber-400/[0.12] font-bold text-amber-200",
          )}
        >
          {value === null ? `${step}초 단위` : formatSeconds(value)}
        </div>
        <button
          onClick={() => onChange(Math.min(max, (value ?? 0) + step))}
          disabled={value !== null && value >= max}
          className={cn(
            stepBtn,
            "bg-white/[0.03] text-slate-300 hover:bg-white/[0.08]",
          )}
          aria-label={`${step}초 늘리기`}
        >
          +
        </button>
      </div>
    </div>
  );
}
export function OptionRow({
  label,
  options,
  value,
  format,
  onSelect,
  disabled,
}) {
  return (
    <div
      className={cn("flex items-center gap-[10px]", disabled && "opacity-35")}
    >
      <span className="w-[118px] shrink-0 text-[13px] font-semibold tracking-[0.06em] text-slate-300">
        {label}
      </span>
      <div className="flex flex-1 overflow-hidden rounded-[2px] border border-white/10">
        {options.map((p, N) => {
          const S = !disabled && Object.is(p, value);
          return (
            <button
              key={N}
              disabled={disabled}
              onClick={() => onSelect(p)}
              className={cn(
                "flex-1 border-r border-white/10 py-[9px] font-mono text-[14px] tabular-nums transition-colors last:border-r-0",
                S
                  ? "bg-amber-400 font-bold text-[#0b0e13]"
                  : "bg-white/[0.03] text-slate-300 hover:bg-white/[0.08]",
              )}
            >
              {format(p)}
            </button>
          );
        })}
      </div>
    </div>
  );
}
export function SetupScreen({ draft, onChange, onStart, onOpenRecords }) {
  const s = (h, p) =>
      onChange({
        ...draft,
        [h]: p,
      }),
    m = draft.mode === "practice",
    z = draft.discipline === "zero";
  return (
    <div className="flex h-full w-full flex-col bg-[#0b0e13]">
      <div className="flex items-center justify-between border-b border-white/10 px-[30px] py-[15px]">
        <div className="flex items-baseline gap-[14px]">
          <span className="text-[24px] font-semibold tracking-[0.16em] text-slate-100">
            ELECTRONIC TARGET
          </span>
          <span className="text-[13px] tracking-[0.22em] text-slate-400">
            10 METER AIR · PERSONAL TRAINING
          </span>
        </div>
        <div className="flex items-center gap-[16px]">
          <button className="records-tab" onClick={onOpenRecords}>
            <span aria-hidden="true">🗂</span>
            <span>
              <strong>개인 기록</strong>
              <small>저장 기록 · 사진/영상 리플레이</small>
            </span>
          </button>
          <span className="font-mono text-[12px] tracking-[0.16em] text-slate-500">
            BATTLE CAMP BB HIT DETECTION SYSTEM
          </span>
        </div>
      </div>
      <div className="grid min-h-0 flex-1 grid-cols-[430px_1fr_460px] gap-[22px] px-[30px] py-[20px]">
        <section className="flex min-h-0 flex-col">
          <h2 className="mb-[10px] text-[13px] font-semibold uppercase tracking-[0.18em] text-slate-400">
            01 / 종목
          </h2>
          <div className="grid min-h-0 flex-1 grid-rows-3 gap-[12px]">
            {["pistol", "rifle", "zero"].map((h) => {
              const p = TARGET_SPECS[h],
                N = draft.discipline === h;
              return (
                <button
                  key={h}
                  onClick={() => s("discipline", h)}
                  aria-pressed={N}
                  className={cn(
                    "flex items-center gap-[16px] rounded-[3px] border px-[16px] text-left transition-colors",
                    N
                      ? "border-amber-400/70 bg-amber-400/[0.07]"
                      : "border-white/10 bg-white/[0.02] hover:border-white/25",
                  )}
                >
                  <div className="h-[118px] w-[118px] shrink-0 bg-[#0e1216] p-[5px]">
                    <svg
                      viewBox={`${-p.cardSize / 2} ${-p.cardSize / 2} ${p.cardSize} ${p.cardSize}`}
                      className="h-full w-full"
                    >
                      <TargetFace spec={p} />
                    </svg>
                  </div>
                  <div className="min-w-0">
                    <div
                      className={cn(
                        "text-[20px] font-semibold",
                        N ? "text-amber-200" : "text-slate-100",
                      )}
                    >
                      {p.label}
                    </div>
                    <div className="mt-[2px] font-mono text-[11px] tracking-[0.12em] text-slate-400">
                      {h === "pistol"
                        ? "10M AIR PISTOL"
                        : h === "rifle"
                          ? "10M AIR RIFLE"
                          : "ZEROING TARGET"}
                    </div>
                    <ul className="mt-[8px] space-y-[3px] text-[12px] leading-snug text-slate-300">
                      {p.specLines.map((S) => (
                        <li key={S} className="flex gap-[6px]">
                          <span className="text-slate-600">·</span>
                          <span className="min-w-0">{S}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </button>
              );
            })}
          </div>
        </section>
        <section className="flex min-h-0 flex-col">
          <h2 className="mb-[10px] text-[13px] font-semibold uppercase tracking-[0.18em] text-slate-400">
            02 / 경기 모드
          </h2>
          {z && (
            <div className="relative flex min-h-0 flex-1 flex-col justify-center gap-[14px] overflow-hidden rounded-[3px] border border-amber-400/30 bg-amber-400/[0.05] p-[22px]">
              {/* 배경: 영점 표적 미리보기 */}
              <svg
                aria-hidden="true"
                className="zero-preview-bg"
                viewBox={`${-TARGET_SPECS.zero.cardWidth / 2} ${-TARGET_SPECS.zero.cardHeight / 2} ${TARGET_SPECS.zero.cardWidth} ${TARGET_SPECS.zero.cardHeight}`}
                preserveAspectRatio="xMidYMid slice"
              >
                <TargetFace spec={TARGET_SPECS.zero} />
              </svg>
              <div className="zero-preview-shade" aria-hidden="true" />
              <div className="relative font-mono text-[13px] tracking-[0.16em] text-amber-200/90">
                ZEROING MODE
              </div>
              <div className="relative text-[19px] font-semibold leading-snug text-amber-100">
                영점 사격은 발수·시간 제한 없이
                <br />
                탄착 위치만 기록합니다.
              </div>
              <ul className="relative space-y-[7px] text-[13px] leading-relaxed text-slate-200">
                <li className="flex gap-[8px]">
                  <span className="text-amber-300/70">·</span> 발수 제한 없음 —
                  원하는 만큼 사격
                </li>
                <li className="flex gap-[8px]">
                  <span className="text-amber-300/70">·</span> 시간 제한 없음 —
                  발당/전체 타이머 미적용
                </li>
                <li className="flex gap-[8px]">
                  <span className="text-amber-300/70">·</span> 점수 채점 없음 —
                  격자 좌표 탄착만 표시
                </li>
              </ul>
            </div>
          )}
          {!z && (
            <div className="grid min-h-0 flex-1 grid-rows-4 gap-[12px]">
              {MATCH_MODES.map((h) => {
                const p = draft.mode === h.id;
                return (
                  <button
                    key={h.id}
                    onClick={() => s("mode", h.id)}
                    aria-pressed={p}
                    className={cn(
                      "flex items-center gap-[16px] rounded-[3px] border px-[18px] text-left transition-colors",
                      p
                        ? "border-amber-400/70 bg-amber-400/[0.07]"
                        : "border-white/10 bg-white/[0.02] hover:border-white/25",
                    )}
                  >
                    <div
                      className={cn(
                        "flex h-[46px] w-[100px] shrink-0 items-center justify-center rounded-[2px] border font-mono text-[12px] tracking-[0.06em]",
                        p
                          ? "border-amber-400/50 bg-amber-400/15 text-amber-200"
                          : "border-white/10 bg-white/[0.03] text-slate-500",
                      )}
                    >
                      {h.code}
                    </div>
                    <div className="min-w-0">
                      <div
                        className={cn(
                          "text-[16px] font-semibold leading-tight",
                          p ? "text-amber-200" : "text-slate-100",
                        )}
                      >
                        {h.title}
                      </div>
                      <div className="mt-[3px] truncate text-[12px] text-slate-300">
                        {h.desc}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </section>
        <section className="flex min-h-0 flex-col">
          <h2 className="mb-[10px] text-[13px] font-semibold uppercase tracking-[0.18em] text-slate-400">
            03 / 사격 설정
          </h2>
          <div className="flex min-h-0 flex-1 flex-col gap-[14px] rounded-[3px] border border-white/10 bg-white/[0.02] p-[16px]">
            {z ? (
              <div className="flex flex-1 flex-col justify-center gap-[10px] text-[14px] leading-relaxed text-slate-300">
                <p>영점 모드에서는 발수·시간·채점 설정을 사용하지 않습니다.</p>
                <p>표적을 사격할 때마다 탄착 위치만 격자에 기록됩니다.</p>
              </div>
            ) : (
              <>
                <div className="setting-fixed">
                  <span>지정 발수</span>
                  <strong>
                    {m ? (
                      "무제한"
                    ) : (
                      <>
                        {MATCH_MODES.find((h) => h.id === draft.mode)?.shots}
                        <small>{" 발"}</small>
                      </>
                    )}
                  </strong>
                  <span>첫 착탄부터 기록</span>
                </div>
                <StepRow
                  label="전체 시간"
                  value={draft.totalSec}
                  step={TOTAL_SEC_STEP}
                  max={TOTAL_SEC_MAX}
                  onChange={(h) => s("totalSec", h)}
                />
                <StepRow
                  label="1발당 시간"
                  value={draft.perShotSec}
                  step={PER_SHOT_SEC_STEP}
                  max={PER_SHOT_SEC_MAX}
                  onChange={(h) => s("perShotSec", h)}
                />
                <OptionRow
                  label="소수점 합산"
                  options={[false, true]}
                  value={draft.decimalTotals}
                  format={(h) => (h ? "ON · 10.9점" : "OFF · 10점")}
                  onSelect={(h) => s("decimalTotals", h)}
                />
                <OptionRow
                  label="효과음"
                  options={[false, true]}
                  value={draft.sound}
                  format={(h) => (h ? "ON" : "OFF")}
                  onSelect={(h) => {
                    s("sound", h);
                    h && playImpactSound();
                  }}
                />
                <div className="mt-[2px] border-t border-white/10 pt-[12px]">
                  <div className="mb-[9px] text-[13px] font-semibold tracking-[0.06em] text-slate-300">
                    {"점수 콜 보이스 "}
                    <span className="ml-[6px] text-[11px] font-normal text-slate-500">
                      선택 시 미리듣기
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-[8px]">
                    {VOICE_OPTIONS.map((h) => {
                      const p = draft.voice === h.id;
                      return (
                        <button
                          key={h.id}
                          onClick={() => {
                            (clearSpeech(),
                              s("voice", h.id),
                              h.id !== "off" &&
                                speakScore(
                                  draft.decimalTotals
                                    ? scoreCallParts(10.9, true)
                                    : scoreCallParts(10, false, true),
                                  h.id,
                                ));
                          }}
                          aria-pressed={p}
                          className={cn(
                            "rounded-[2px] border px-[10px] py-[10px] text-left transition-colors",
                            p
                              ? "border-amber-400/70 bg-amber-400/[0.09]"
                              : "border-white/10 bg-white/[0.03] hover:border-white/25",
                          )}
                        >
                          <div
                            className={cn(
                              "text-[15px] font-semibold",
                              p ? "text-amber-200" : "text-slate-200",
                            )}
                          >
                            {h.label}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
                <div className="mt-auto space-y-[5px] border-t border-white/10 pt-[11px] text-[12px] leading-relaxed text-slate-400">
                  <p>
                    첫 착탄부터 모든 샷이 기록되며 지정 발수 도달 시 결과가 자동
                    표시됩니다.
                  </p>
                  <p>
                    발당 시간 초과는 0.0점입니다. 0.1~0.9점은 게임용 확장
                    점수입니다.
                  </p>
                  <p>
                    음성은 샷 순서대로 끝까지 재생됩니다. 음색은 기기에 설치된
                    영어 음성에 따라 달라집니다.
                  </p>
                </div>
              </>
            )}
          </div>
        </section>
      </div>
      <div className="flex items-stretch justify-between border-t border-white/10">
        <div className="flex items-center gap-[22px] px-[30px] py-[14px] text-[14px] text-slate-400">
          <span className="font-mono text-[15px] tracking-[0.06em] text-slate-200">
            {z
              ? "영점 사격"
              : `${TARGET_SPECS[draft.discipline]?.label ?? ""} · ${MATCH_MODES.find((h) => h.id === draft.mode)?.title ?? ""}`}
          </span>
          <span className="text-slate-700">|</span>
          <span>
            {z
              ? "발수 무제한 · 시간 제한 없음 · 점수 미채점 · 탄착만 기록"
              : `${
                  m
                    ? "무제한"
                    : `${MATCH_MODES.find((h) => h.id === draft.mode)?.shots}발`
                }
                · 전체 ${draft.totalSec === null ? "제한 없음" : formatSeconds(draft.totalSec)}
                · 발당 ${draft.perShotSec === null ? "제한 없음" : formatSeconds(draft.perShotSec)}
                · 소수점 합산 ${draft.decimalTotals ? "ON" : "OFF"}`}
          </span>
        </div>
        <button
          onClick={onStart}
          className="min-w-[260px] bg-amber-400 px-[42px] text-[21px] font-bold tracking-[0.12em] text-[#0b0e13] transition-colors hover:bg-amber-300"
        >
          사격 시작
        </button>
      </div>
    </div>
  );
}
