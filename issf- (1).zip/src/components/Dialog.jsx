import React from "react";

export function Dialog({ children, labelId, onClose, className = "" }) {
  const m = React.useRef(null),
    h = React.useRef(onClose);
  return (
    (h.current = onClose),
    React.useEffect(() => {
      const p = document.activeElement,
        N = m.current;
      N?.focus();
      const S = (x) => {
        if (
          (x.key === "Escape" &&
            (x.preventDefault(), x.stopPropagation(), h.current()),
          x.key !== "Tab" || !N)
        )
          return;
        const H = Array.from(
            N.querySelectorAll(
              'button:not(:disabled), input:not(:disabled), [tabindex="0"]',
            ),
          ),
          C = H[0],
          Y = H[H.length - 1];
        if (!C) {
          x.preventDefault();
          return;
        }
        x.shiftKey &&
        (document.activeElement === C || document.activeElement === N)
          ? (x.preventDefault(), Y.focus())
          : !x.shiftKey &&
            (document.activeElement === Y || document.activeElement === N) &&
            (x.preventDefault(), C.focus());
      };
      return (
        document.addEventListener("keydown", S, true),
        () => {
          (document.removeEventListener("keydown", S, true),
            p?.isConnected && p.focus());
        }
      );
    }, []),
    (
      <div className="dialog-backdrop">
        <div
          ref={m}
          role="dialog"
          aria-modal="true"
          aria-labelledby={labelId}
          tabIndex={-1}
          className={`dialog-sheet ${className}`}
        >
          {children}
        </div>
      </div>
    )
  );
}
