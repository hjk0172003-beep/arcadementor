import { ShotMarks } from "./ShotMarks";
import { TargetFace } from "./TargetFace";
import { formatTotal, seriesTotal } from "../lib/stats";

export function SeriesStrip({
  spec,
  series,
  offset,
  activeIndex,
  onSelect,
  onPrevious,
  onNext,
  canPrevious,
  canNext,
}) {
  const x = spec.cardSize / 2;
  return (
    <div className="series-strip flex h-full min-h-0 flex-col gap-[7px]">
      <div className="flex h-[24px] shrink-0 items-center justify-between px-[2px] text-[10px] tracking-[0.13em] text-slate-400">
        <span>시리즈</span>
        <div className="flex gap-[2px]">
          <button
            aria-label="이전 시리즈"
            onClick={onPrevious}
            disabled={!canPrevious}
            className="strip-nav"
          >
            {"<"}
          </button>
          <button
            aria-label="다음 시리즈"
            onClick={onNext}
            disabled={!canNext}
            className="strip-nav"
          >
            {">"}
          </button>
        </div>
      </div>
      {series.map((H, C) => {
        const Y = offset + C,
          F = Y === activeIndex;
        return (
          <button
            key={Y}
            className={`series-preview ${F ? "is-selected" : ""}`}
            aria-label={
              spec.zeroing
                ? `${Y + 1}시리즈 ${H.length}발 보기`
                : `${Y + 1}시리즈 ${formatTotal(seriesTotal(H, spec), spec.decimalTotals)}점 보기`
            }
            aria-pressed={F}
            onClick={() => onSelect(Y)}
          >
            <div className="series-preview-head">
              <span>{String(Y + 1).padStart(2, "0")}</span>
              <strong className="font-mono tabular-nums">
                {spec.zeroing
                  ? `${H.length}발`
                  : formatTotal(seriesTotal(H, spec), spec.decimalTotals)}
              </strong>
            </div>
            <div
              className={`series-preview-target ${H.length ? "" : "is-empty"}`}
            >
              <svg
                viewBox={`${-x} ${-x} ${x * 2} ${x * 2}`}
                className="h-full w-full"
                aria-hidden="true"
              >
                <TargetFace spec={spec} plain />
                <ShotMarks
                  shots={H}
                  spec={spec}
                  stroke={spec.cardSize * 0.009}
                />
              </svg>
            </div>
            <div className="series-preview-count">
              {H.length}
              {" / 10"}
            </div>
          </button>
        );
      })}
    </div>
  );
}
