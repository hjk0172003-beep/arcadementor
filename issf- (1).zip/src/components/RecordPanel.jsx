import { seriesShots, visibleSeriesWindow } from "../lib/session";
import {
  bearingDeg,
  cumulativeTotals,
  fixed,
  formatTotal,
  seriesTotal,
  splitDecimal,
} from "../lib/stats";

export function DirectionArrow({
  x: u,
  y,
  dead = 0.35,
  size = 16,
  color = "currentColor",
  opacity = 1,
}) {
  if (Math.hypot(u, y) < dead)
    return (
      <svg
        width={size}
        height={size}
        viewBox="0 0 24 24"
        style={{
          opacity: opacity,
        }}
      >
        <circle
          cx="12"
          cy="12"
          r="3.2"
          fill="none"
          stroke={color}
          strokeWidth="2"
        />
      </svg>
    );
  const N = bearingDeg(u, y);
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      style={{
        opacity: opacity,
      }}
    >
      <g
        transform={`rotate(${N.toFixed(1)} 12 12)`}
        stroke={color}
        strokeWidth="2"
        fill="none"
        strokeLinecap="square"
      >
        <line x1="12" y1="20" x2="12" y2="5" />
        <polyline points="7,10 12,4.5 17,10" />
      </g>
    </svg>
  );
}
export function ScoreNumber({ value, large = false, integer = false }) {
  if (integer)
    return (
      <span className={`score-number ${large ? "score-number-large" : ""}`}>
        <span>{String(Math.round(value))}</span>
      </span>
    );
  const [o, s] = splitDecimal(value);
  return (
    <span className={`score-number ${large ? "score-number-large" : ""}`}>
      <span>{o}</span>
      <span className="score-fraction">.{s}</span>
    </span>
  );
}
export function RecordPanel({
  session,
  spec,
  last,
  seriesIndex,
  shownStats,
  totalStats,
  view,
  scopeLabel,
  onView,
  onSeries,
  onShot,
}) {
  const C = spec.zeroing
      ? session.shots.slice(Math.max(0, session.shots.length - 10))
      : seriesShots(session, seriesIndex),
    Y = visibleSeriesWindow(session, seriesIndex),
    F = cumulativeTotals(session.shots, spec),
    ct = spec.zeroing
      ? [
          {
            key: "all",
            label: "전체 탄착",
            value: session.shots.length,
            count: session.shots.length,
            desc: "전체 샷",
          },
        ]
      : [
          {
            key: "first40",
            label: "40샷 합계",
            value: F.first40,
            count: Math.min(40, session.shots.length),
            desc: "1~40번 샷",
          },
          {
            key: "first60",
            label: "60샷 합계",
            value: F.first60,
            count: Math.min(60, session.shots.length),
            desc: "1~60번 샷",
          },
          {
            key: "all",
            label: "합계",
            value: F.total,
            count: session.shots.length,
            desc: "전체 샷",
          },
        ];
  return (
    <section className="result-panel" aria-label="샷 기록 및 결과">
      <div className="report-heading">
        <span>
          {"SHOT REPORT "}
          <span className="report-live-dot" />
          {" 실시간 기록"}
        </span>
        <span>
          {spec.zeroing ? (
            "격자 좌표 기록 · 점수 미채점"
          ) : (
            <>
              {spec.decimalTotals ? "소수점 합계" : "정수 합계"}{" "}
              <span className="text-slate-600">/</span>{" "}
              {session.config.shots ?? "무제한"}발
            </>
          )}
        </span>
      </div>
      <div className="report-series-heading">
        <h2>
          {spec.zeroing ? (
            "최근 탄착"
          ) : (
            <>
              <span className="font-mono">
                {String(seriesIndex + 1).padStart(2, "0")}
              </span>
              {" 시리즈"}
            </>
          )}
        </h2>
        <div>
          <span>
            {spec.zeroing ? `최근 ${C.length}발` : `${C.length} / 10 샷`}
          </span>
          <strong className="font-mono" data-testid="series-total">
            {spec.zeroing ? (
              <>
                {C.length}
                <small>{" 발"}</small>
              </>
            ) : (
              <>
                {formatTotal(seriesTotal(C, spec), spec.decimalTotals)}
                <small>{" 점"}</small>
              </>
            )}
          </strong>
        </div>
      </div>
      <div className="shot-record-grid" aria-label="시리즈 샷 목록">
        {Array.from(
          {
            length: 5,
          },
          (Z, k) => [k, k + 5],
        )
          .flat()
          .map((Z) => {
            const k = C[Z];
            return (
              <button
                key={Z}
                className={`shot-record ${k?.id === last?.id ? "is-selected" : ""} ${k ? "has-shot" : ""}`}
                disabled={!k}
                onClick={() => k && onShot(k)}
                aria-label={
                  k
                    ? spec.zeroing
                      ? `샷 ${k.index} 탄착`
                      : `샷 ${k.index}, ${k.decimal.toFixed(1)}점${k.inner ? ", 엑스텐" : ""}`
                    : spec.zeroing
                      ? "탄착 대기"
                      : `${Z + 1}번 샷 대기`
                }
              >
                <span className="shot-record-index">
                  {String(
                    k?.index ??
                      (spec.zeroing
                        ? session.shots.length + Z + 1
                        : seriesIndex * 10 + Z + 1),
                  ).padStart(2, "0")}
                </span>
                {k ? (
                  spec.zeroing ? (
                    <span className="zero-hit-dot" />
                  ) : (
                    <ScoreNumber
                      value={k.decimal}
                      integer={!spec.decimalTotals}
                    />
                  )
                ) : (
                  <span className="empty-record">--</span>
                )}
                <span className="shot-record-special">
                  {k?.inner ? "X" : k?.miss ? "T/O" : ""}
                </span>
                {k && !k.miss ? (
                  <DirectionArrow x={k.x} y={k.y} size={20} dead={0.001} />
                ) : (
                  <span className="w-[20px]" />
                )}
              </button>
            );
          })}
      </div>
      <div className="shot-readout">
        <div className="latest-score">
          <div className="readout-label">
            <span>
              {"샷 "}
              <span className="font-mono">
                {last ? String(last.index).padStart(2, "0") : "--"}
              </span>
            </span>
            <span>
              {last?.inner
                ? "X-TEN"
                : last?.miss
                  ? "시간 초과"
                  : last && last.index < session.shots.length
                    ? "선택 기록"
                    : "최근 착탄"}
            </span>
          </div>
          <div
            key={`${session.id}-${last?.id ?? 0}`}
            className="latest-score-value"
            data-testid="last-score"
          >
            {last ? (
              spec.zeroing ? (
                <span className="zero-shot-label">
                  <strong>{last.index}</strong>
                  <span>발째</span>
                </span>
              ) : (
                <ScoreNumber
                  value={last.decimal}
                  large
                  integer={!spec.decimalTotals}
                />
              )
            ) : (
              <span className={spec.zeroing ? "zero-shot-label is-empty" : "empty-score"}>
                {spec.zeroing ? (
                  <>
                    <strong>--</strong>
                    <span>발째</span>
                  </>
                ) : (
                  <>0{spec.decimalTotals && <span>.0</span>}</>
                )}
              </span>
            )}
            <div className="shot-deviation">
              {last && !last.miss ? (
                <>
                  <span>
                    {fixed(Math.abs(last.y))}
                    <small>mm</small>
                    <DirectionArrow x={0} y={last.y} size={18} dead={0.001} />
                  </span>
                  <span>
                    {fixed(Math.abs(last.x))}
                    <small>mm</small>
                    <DirectionArrow x={last.x} y={0} size={18} dead={0.001} />
                  </span>
                </>
              ) : (
                <span className="text-slate-500">중심 기준 편차</span>
              )}
            </div>
          </div>
        </div>
        <div
          className="ctc-readout"
          title="선택한 구간에서 가장 멀리 떨어진 두 착탄 중심 사이의 거리입니다. 시간 초과 기록은 제외합니다."
        >
          <div className="readout-label">
            <span>CTC</span>
            <span>{scopeLabel}</span>
          </div>
          <div className="ctc-value" data-testid="ctc-value">
            {shownStats.hitCount > 1 ? fixed(shownStats.ctc) : "--"}
            <small>mm</small>
          </div>
          <div className="ctc-caption">
            {"탄착 중심 간 최대 거리 "}
            <span>{shownStats.hitCount}발</span>
          </div>
        </div>
      </div>
      {!spec.zeroing && (
        <div className="series-score-row">
          <span className="series-score-label">시리즈 합계</span>
          <div
            className="series-score-buttons"
            style={{
              gridTemplateColumns: `repeat(${Y.list.length}, minmax(0, 1fr))`,
            }}
          >
            {Y.list.map((Z, k) => (
              <button
                key={k}
                onClick={() => onSeries(Y.offset + k)}
                aria-pressed={seriesIndex === Y.offset + k && view === "series"}
              >
                <small>{String(Y.offset + k + 1).padStart(2, "0")}</small>
                <strong>
                  {spec.zeroing
                    ? `${Z.length}발`
                    : formatTotal(seriesTotal(Z, spec), spec.decimalTotals)}
                </strong>
              </button>
            ))}
          </div>
        </div>
      )}
      <div className="session-stat-row">
        {spec.zeroing ? (
          <div>
            <span>총 탄착</span>
            <strong>
              {totalStats.hitCount}
              <small>{" 발"}</small>
            </strong>
          </div>
        ) : (
          <>
            <div>
              <span>평균 점수</span>
              <strong>
                {totalStats.n ? totalStats.avgDecimal.toFixed(2) : "0.00"}
              </strong>
            </div>
            <div>
              <span>엑스텐</span>
              <strong>
                {totalStats.inners}
                <small>{" X"}</small>
              </strong>
            </div>
          </>
        )}
        <div>
          <span>기록 샷</span>
          <strong>
            {session.shots.length}
            <small>
              {" / "}
              {session.config.shots ?? "무제한"}
            </small>
          </strong>
        </div>
      </div>
      <div className="cumulative-scores">
        {ct.map((Z) => (
          <button
            key={Z.key}
            className={`cumulative-row ${Z.key === "all" ? "grand-total" : ""}`}
            onClick={() => onView(Z.key)}
            aria-pressed={view === Z.key}
            title={`${Z.desc} 탄착 보기`}
            data-testid={`total-${Z.key}`}
          >
            <span className="cumulative-title">
              {Z.label}
              <small>
                {Z.desc} <span className="text-slate-500">·</span>
                {" 현재 "}
                {Z.count}발
              </small>
            </span>
            <strong className="font-mono tabular-nums">
              {spec.zeroing ? (
                <>
                  {Z.count}
                  <small>{" 발"}</small>
                </>
              ) : (
                <>
                  {formatTotal(Z.value, spec.decimalTotals)}
                  <small>{" 점"}</small>
                </>
              )}
            </strong>
            <span className="scope-arrow" aria-hidden="true">
              ↗
            </span>
          </button>
        ))}
      </div>
    </section>
  );
}
