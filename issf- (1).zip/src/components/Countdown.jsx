import React from "react";
import { cn } from "../utils/cn";
import { formatClock } from "../lib/stats";

export function Countdown({ deadline, duration, label }) {
  const [s, m] = React.useState(() => Date.now());
  React.useEffect(() => {
    if (deadline === null) return;
    m(Date.now());
    const x = setInterval(() => m(Date.now()), 100);
    return () => clearInterval(x);
  }, [deadline]);
  const h = deadline === null ? duration : Math.max(0, deadline - s),
    p = h !== null && h <= 1e4,
    N = h !== null && h <= 3e4 && !p,
    S = h !== null && duration ? h / duration : null;
  return (
    <div className="flex items-center gap-[12px]">
      <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-slate-500">
        {label}
      </span>
      <div className="flex flex-col items-end">
        <span
          className={cn(
            "font-mono text-[26px] font-semibold leading-none tabular-nums",
            deadline === null
              ? "text-slate-400"
              : p
                ? "text-red-400"
                : N
                  ? "text-amber-300"
                  : "text-slate-100",
          )}
        >
          {formatClock(h)}
        </span>
        {S !== null && deadline !== null && (
          <span className="mt-[4px] block h-[3px] w-[132px] bg-white/10">
            <span
              className={cn(
                "block h-full",
                p ? "bg-red-500" : N ? "bg-amber-400" : "bg-slate-300",
              )}
              style={{
                width: `${Math.max(0, Math.min(1, S)) * 100}%`,
              }}
            />
          </span>
        )}
      </div>
    </div>
  );
}
