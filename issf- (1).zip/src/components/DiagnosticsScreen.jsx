import React from "react";
import { runLogicTests, runSvgTransformTest } from "../diagnostics/tests";

export function DiagnosticsScreen() {
  const [u, d] = React.useState([]),
    o = () => d([...runLogicTests(), runSvgTransformTest()]);
  React.useEffect(() => {
    o();
  }, []);
  const s = u.filter((m) => !m.passed).length;
  return (
    <div className="diagnostics-screen">
      <header>
        <div>
          <span className="eyebrow">SYSTEM DIAGNOSTICS</span>
          <h1>회귀 검사</h1>
          <p>채점, 발수 종료, 시리즈, 합계, 음성 대기열 및 SVG 좌표 변환</p>
        </div>
        <strong>
          {u.length ? `${u.length - s} / ${u.length} PASS` : "검사 중"}
        </strong>
      </header>
      <div className="diagnostics-list">
        {u.map((m, h) => (
          <div key={h}>
            <span className={m.passed ? "check-pass" : "check-fail"}>
              {m.passed ? "PASS" : "FAIL"}
            </span>
            <span>
              {m.name}
              {m.error && <small>{m.error}</small>}
            </span>
          </div>
        ))}
      </div>
      <footer>
        <span>
          실제 음성 출력과 BB 센서는 해당 기기에서 별도로 확인해야 합니다.
        </span>
        <button className="console-button" onClick={o}>
          다시 검사
        </button>
        <button
          className="console-button primary"
          onClick={() => {
            window.location.search = "";
          }}
        >
          메뉴
        </button>
      </footer>
    </div>
  );
}
