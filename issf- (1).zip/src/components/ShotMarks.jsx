import { PELLET_RADIUS } from "../lib/targetSpec";

export const HIT_COLOR = "#25c246",
  LAST_HIT_COLOR = "#ee3b1f";
export function ShotMarks({
  shots,
  spec,
  stroke,
  lastId = null,
  numbers = false,
  numberField = "no",
  fontSize = 3,
}) {
  return (
    <g pointerEvents="none" data-testid="shot-marks">
      {shots
        .filter((p) => !p.miss)
        .map((p) => {
          const N = p.id === lastId,
            S = N ? LAST_HIT_COLOR : HIT_COLOR,
            R = spec.zeroing ? 2.6 : PELLET_RADIUS;
          return (
            <g key={p.id} data-shot-index={p.index}>
              <circle
                cx={p.x}
                cy={p.y}
                r={R}
                fill="none"
                stroke="#0b0b0b"
                strokeWidth={stroke * 1.9}
                opacity={0.35}
              />
              <circle
                cx={p.x}
                cy={p.y}
                r={R}
                fill="none"
                stroke={S}
                strokeWidth={stroke}
              />
              <circle cx={p.x} cy={p.y} r={stroke * 0.7} fill={S} />
              {N && (
                <circle
                  className="impact-echo"
                  cx={p.x}
                  cy={p.y}
                  r={R * 1.6}
                  fill="none"
                  stroke={S}
                  strokeWidth={stroke}
                />
              )}
              {numbers && (
                <text
                  x={p.x + R * 1.35}
                  y={p.y - R * 1.05}
                  fill={S}
                  fontSize={fontSize}
                  fontFamily="Helvetica, Arial, sans-serif"
                  fontWeight={700}
                  dominantBaseline="central"
                  stroke="#0b0b0b"
                  strokeWidth={fontSize * 0.09}
                  paintOrder="stroke"
                >
                  {numberField === "index" ? p.index : p.no}
                </text>
              )}
            </g>
          );
        })}
      {!spec.zeroing && (
        <g opacity={0.5}>
          <line
            x1={-spec.tenRadius * 1.5}
            x2={spec.tenRadius * 1.5}
            y1={0}
            y2={0}
            stroke="#9aa3ad"
            strokeWidth={stroke * 0.5}
          />
          <line
            y1={-spec.tenRadius * 1.5}
            y2={spec.tenRadius * 1.5}
            x1={0}
            x2={0}
            stroke="#9aa3ad"
            strokeWidth={stroke * 0.5}
          />
        </g>
      )}
    </g>
  );
}
