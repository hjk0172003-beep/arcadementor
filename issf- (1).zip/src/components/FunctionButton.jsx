export function FunctionButton({
  label,
  description,
  onClick,
  active = false,
  disabled = false,
}) {
  return (
    <button
      className={`function-button ${active ? "is-active" : ""}`}
      onClick={onClick}
      disabled={disabled}
    >
      <span>
        <strong>{label}</strong>
        <small>{description}</small>
      </span>
    </button>
  );
}
