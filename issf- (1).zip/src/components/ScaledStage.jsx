import React from "react";

export const STAGE_WIDTH = 1600,
  STAGE_HEIGHT = 900;
export function ScaledStage({ children }) {
  const d = React.useRef(null),
    [o, s] = React.useState(1);
  return (
    React.useEffect(() => {
      const m = d.current;
      if (!m) return;
      const h = () => {
        const { clientWidth: N, clientHeight: S } = m;
        if (N > 0 && S > 0) {
          s(Math.min(N / STAGE_WIDTH, S / STAGE_HEIGHT));
        }
      };
      h();
      const p = new ResizeObserver(h);
      return (
        p.observe(m),
        window.addEventListener("resize", h),
        () => {
          (p.disconnect(), window.removeEventListener("resize", h));
        }
      );
    }, []),
    (
      <div
        ref={d}
        className="flex h-screen w-screen items-center justify-center overflow-hidden bg-black"
      >
        <div
          style={{
            width: STAGE_WIDTH,
            height: STAGE_HEIGHT,
            transform: `scale(${o})`,
            transformOrigin: "center center",
          }}
          className="relative shrink-0 select-none bg-[#0b0e13] text-slate-200 antialiased"
        >
          {children}
        </div>
      </div>
    )
  );
}
