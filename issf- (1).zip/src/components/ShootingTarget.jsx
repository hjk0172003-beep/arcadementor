import React from "react";
import { ShotMarks } from "./ShotMarks";
import { TargetFace } from "./TargetFace";
import { svgPointFromClient } from "../lib/geometry";

export function ShootingTarget({
  spec,
  shots,
  lastId,
  armed,
  showShots = true,
  numberField = "no",
  showNumbers,
  onHit,
}) {
  const S = React.useRef(null),
    x = React.useRef(null),
    H = spec.cardSize * 0.51,
    vw = spec.cardWidth ?? H * 2,
    vh = spec.cardHeight ?? H * 2,
    C = vh / 100,
    vx = -vw / 2,
    vy = spec.zeroing
      ? -spec.gridTop * spec.gridCell
      : -vh / 2 + (spec.cardOffsetY ?? 0);
  return (
    React.useEffect(() => {
      !armed && x.current && (x.current.style.display = "none");
    }, [armed]),
    (
      <div className="main-target h-full w-full overflow-hidden rounded-[3px] bg-[#fbfaf6]">
        <svg
          ref={S}
          data-testid="shooting-target"
          aria-label={`${spec.label} 착탄 인식 표적`}
          data-discipline={spec.discipline}
          data-armed={armed}
          viewBox={`${vx} ${vy} ${vw} ${vh}`}
          preserveAspectRatio="xMidYMid meet"
          className={`h-full w-full touch-none ${armed ? "cursor-none" : "cursor-default"}`}
          onPointerMove={(Y) => {
            if (!S.current || !x.current) return;
            const F = svgPointFromClient(S.current, H, Y.clientX, Y.clientY);
            F &&
              (x.current.setAttribute("transform", `translate(${F.x} ${F.y})`),
              (x.current.style.display = armed ? "" : "none"));
          }}
          onPointerLeave={() => {
            x.current && (x.current.style.display = "none");
          }}
          onClick={(Y) => {
            if (Y.button !== 0 || !armed || !S.current) return;
            const F = svgPointFromClient(S.current, H, Y.clientX, Y.clientY);
            F &&
              F.x >= vx &&
              F.x <= vx + vw &&
              F.y >= vy &&
              F.y <= vy + vh &&
              onHit(F.x, F.y);
          }}
          onContextMenu={(Y) => Y.preventDefault()}
        >
          <TargetFace spec={spec} plain={!showNumbers} />
          {showShots && (
            <ShotMarks
              shots={shots}
              spec={spec}
              stroke={spec.zeroing ? 0.7 : C * 0.38}
              lastId={lastId}
              numbers
              numberField={numberField}
              fontSize={spec.zeroing ? 6 : spec.cardSize * 0.024}
            />
          )}
          <g
            ref={x}
            style={{
              display: "none",
            }}
            pointerEvents="none"
            stroke="#ed873c"
            strokeWidth={C * 0.25}
          >
            <path
              d={`M ${-C * 2.2} 0 H ${-C * 0.6} M ${C * 0.6} 0 H ${C * 2.2} M 0 ${-C * 2.2} V ${-C * 0.6} M 0 ${C * 0.6} V ${C * 2.2}`}
            />
            <circle r={C * 0.18} fill="#ed873c" stroke="none" />
          </g>
        </svg>
      </div>
    )
  );
}
