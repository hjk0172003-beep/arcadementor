import React from "react";
import { Countdown } from "./Countdown";
import { Dialog } from "./Dialog";
import { FunctionButton } from "./FunctionButton";
import { RecordPanel } from "./RecordPanel";
import { ResultsSheet } from "./ResultsSheet";
import { ScaledStage } from "./ScaledStage";
import { SeriesStrip } from "./SeriesStrip";
import { RecordsScreen } from "./RecordsScreen";
import { SetupScreen } from "./SetupScreen";
import { ShootingTarget } from "./ShootingTarget";
import { SpeechStatus } from "./SpeechStatus";
import { playImpactSound, playTone } from "../lib/audio";
import {
  createSession,
  currentSeriesIndex,
  isSessionOpen,
  lastShot,
  seriesCount,
  sessionReducer,
  sessionStatusText,
  shotsForView,
  visibleSeriesWindow,
} from "../lib/session";
import {
  clearSpeech,
  primeSpeech,
  scoreCallParts,
  speakScore,
} from "../lib/speech";
import { computeStats, cumulativeTotals } from "../lib/stats";
import { saveRecord } from "../lib/records";
import { MATCH_MODES, STAGE_PX_PER_MM, TARGET_SPECS } from "../lib/targetSpec";

export const DEFAULT_DRAFT = {
  discipline: "pistol",
  mode: "m60",
  practiceShots: 40,
  totalSec: null,
  perShotSec: null,
  voice: "male",
  scoring: "point",
  decimalTotals: false,
  sound: true,
};
export function draftToConfig(u) {
  const d = MATCH_MODES.find((o) => o.id === u.mode);
  // 영점 모드: 발수·시간 제한 없음, 채점 없음
  if (u.discipline === "zero")
    return {
      mode: "practice",
      discipline: "zero",
      shots: null,
      perShotSec: null,
      totalSec: null,
      scoring: "point",
      decimalTotals: false,
    };
  return {
    mode: u.mode,
    discipline: u.discipline,
    shots: u.mode === "practice" ? null : d.shots,
    perShotSec: u.perShotSec,
    totalSec: u.totalSec,
    scoring: u.scoring,
    decimalTotals: u.decimalTotals,
  };
}

function TargetCaption({ zeroing, marksOff, scope, hitCount, voice }) {
  return (
    <div className="target-caption">
      <div className="target-legend">
        <span>
          <i className="legend-last" />
          선택 샷
        </span>
        <span>
          <i className="legend-group" />
          이전 샷
        </span>
      </div>
      <div className="target-scope">
        <strong>{marksOff ? "탄착 표시 꺼짐" : scope}</strong>
        <span data-testid="display-shot-count">
          {marksOff ? "탄착 숨김" : `${hitCount}발 표시`}
        </span>
      </div>
      <div className="target-scoring">
        {zeroing ? (
          <strong className="text-slate-500">점수 미채점</strong>
        ) : (
          <SpeechStatus voice={voice} />
        )}
      </div>
    </div>
  );
}

export function RangeConsole() {
  const [u, d] = React.useState("menu"),
    [o, s] = React.useState(DEFAULT_DRAFT),
    [m, h] = React.useState(() => createSession(draftToConfig(DEFAULT_DRAFT))),
    p = React.useRef(m),
    [N, S] = React.useState("series"),
    [x, H] = React.useState(null),
    [C, Y] = React.useState(null),
    [F, ct] = React.useState(true),
    [marksOff, setMarksOff] = React.useState(false),
    // 오발 방지: 잠금 상태에서는 표적 외 버튼 조작이 막힙니다.
    [locked, setLocked] = React.useState(true),
    [savedRecordId, setSavedRecordId] = React.useState(null),
    [Nt, K] = React.useState(null),
    [rt, dt] = React.useState(null),
    I = React.useCallback((it) => {
      const qt = p.current,
        se = sessionReducer(qt, it);
      return (qt !== se && ((p.current = se), h(se)), se);
    }, []),
    G = m.phase === "finished",
    Dt = G && Nt !== m.id,
    _e = React.useRef(false);
  _e.current = u !== "range" || Dt || rt !== null;
  const $t = m.shots.length,
    Rt = React.useMemo(
      () => ({
        ...TARGET_SPECS[m.discipline],
        decimalTotals: m.config.decimalTotals,
      }),
      [m.discipline, m.config.decimalTotals],
    ),
    // 실물 크기: 표적 SVG는 cardSize의 1.02배 영역을 보여주므로 그만큼 픽셀로 환산
    realSizePx = Rt.cardSize * 1.02 * STAGE_PX_PER_MM,
    Oe = MATCH_MODES.find((it) => it.id === m.config.mode),
    It = currentSeriesIndex(m),
    zt =
      x ??
      (N === "first40"
        ? Math.min(It, 3)
        : N === "first60"
          ? Math.min(It, 5)
          : It);
  // 음성 엔진을 미리 깨워 첫 샷 안내가 지연되지 않게 합니다.
  React.useEffect(() => {
    primeSpeech();
  }, []);
  // 영점 모드는 시리즈 개념이 없으므로 항상 전체 탄착 보기로 고정합니다.
  React.useEffect(() => {
    if (Rt.zeroing && N !== "all") S("all");
  }, [Rt.zeroing, N]);
  React.useEffect(() => {
    if (u !== "range" || m.phase !== "live") return;
    const it = () =>
        I({
          type: "tick",
          now: Date.now(),
        }),
      qt = window.setInterval(it, 100);
    return (
      document.addEventListener("visibilitychange", it),
      () => {
        (clearInterval(qt),
          document.removeEventListener("visibilitychange", it));
      }
    );
  }, [u, m.phase, I]);
  const A = React.useRef({
    id: m.id,
    count: 0,
  });
  React.useEffect(() => {
    A.current.id !== m.id &&
      (A.current = {
        id: m.id,
        count: 0,
      });
    const it = m.shots.slice(A.current.count);
    if (((A.current.count = m.shots.length), o.voice !== "off" && !Rt.zeroing))
      for (const qt of it)
        speakScore(
          qt.miss
            ? m.config.decimalTotals
              ? ["Time out.", "Zero point zero."]
              : ["Time out.", "Zero."]
            : scoreCallParts(qt.decimal, qt.inner, !m.config.decimalTotals),
          o.voice,
        );
  }, [m.id, m.shots, m.config.decimalTotals, o.voice]);
  const q = React.useRef(null);
  (React.useEffect(() => {
    G &&
      q.current !== m.id &&
      ((q.current = m.id), o.sound && playTone(660, 0.18, 0.08));
  }, [G, m.id, o.sound]),
    React.useEffect(() => () => clearSpeech(), []));
  const R = (it) => {
      (S(it), H(null), Y(null));
    },
    st = (it) => {
      (H(Math.max(0, Math.min(seriesCount(m) - 1, it))), S("series"), Y(null));
    },
    vt = () => {
      (clearSpeech(),
        I({
          type: "reset",
          session: createSession(p.current.config),
        }),
        K(null),
        dt(null),
        R("series"));
    },
    v = () => {
      (clearSpeech(),
        I({
          type: "reset",
          session: createSession(draftToConfig(o)),
        }),
        K(null),
        dt(null),
        R("series"),
        d("range"));
    },
    _ = () => {
      (clearSpeech(), dt(null), d("menu"));
    },
    U = () => {
      p.current.phase === "live" ? dt("menu") : _();
    },
    B = React.useCallback(
      (it, qt) => {
        const se = p.current;
        if (_e.current || !isSessionOpen(se)) return;
        const ne = I({
            type: "shot",
            x: it,
            y: qt,
            now: Date.now(),
          }),
          fn = lastShot(ne);
        ne.shots.length > se.shots.length &&
          fn &&
          !fn.miss &&
          (o.sound && playImpactSound(), H(null), Y(null), setLocked(true));
      },
      [I, o.sound],
    ),
    P = () => {
      (p.current.phase === "ready" &&
        (I({
          type: "begin",
          now: Date.now(),
        }),
        o.sound && playTone(1240, 0.12, 0.1)),
        R("series"));
    },
    et = () => {
      G ? K(null) : dt("finish");
    },
    $ = (it) => {
      (K(m.id), it !== void 0 ? st(it) : R("all"));
    },
    // 결과 화면 → 기록 저장 후 개인 기록 탭으로 이동
    onSaveRecord = ({ name, total }) => {
      const rec = saveRecord(m, {
        name,
        total: Rt.zeroing
          ? m.shots.length
          : (total ?? cumulativeTotals(m.shots, Rt).total),
        spec: Rt,
      });
      (clearSpeech(), setSavedRecordId(rec.id), K(m.id), d("records"));
    };
  React.useEffect(() => {
    const it = (qt) => {
      if (
        u !== "range" ||
        rt ||
        Dt ||
        locked ||
        qt.repeat ||
        qt.ctrlKey ||
        qt.metaKey ||
        qt.altKey
      )
        return;
      const se = qt.target;
      if (
        se?.closest(
          'input, textarea, select, [contenteditable="true"], [role="dialog"]',
        )
      )
        return;
      const ne = qt.key.toLowerCase();
      ((ne === "enter" || ne === " ") && se?.closest("button")) ||
        ((ne === "a" || ne === "enter" || ne === " ") &&
          (qt.preventDefault(), P()),
        ne === "b" && (setMarksOff(false), R("all")),
        ne === "n" && (setMarksOff(false), R("series")),
        ne === "x" && setMarksOff((pn) => !pn),
        (ne === "c" || ne === "r") && dt("reset"),
        ne === "d" && (G || $t > 0) && et(),
        (ne === "e" || ne === "escape") && U());
    };
    return (
      window.addEventListener("keydown", it),
      () => window.removeEventListener("keydown", it)
    );
  });
  const Ht = React.useMemo(() => shotsForView(m, N, x), [m, N, x]),
    xt = React.useMemo(() => computeStats(Ht), [Ht]),
    ve = React.useMemo(() => computeStats(m.shots), [m.shots]),
    Xe = React.useMemo(() => visibleSeriesWindow(m, zt), [m, zt]),
    Qe =
      C !== null
        ? (m.shots.find((it) => it.id === C) ?? null)
        : (Ht[Ht.length - 1] ?? null),
    va =
      N === "all"
        ? "전체 탄착"
        : N === "first40"
          ? "1~40 샷"
          : N === "first60"
            ? "1~60 샷"
            : `${zt + 1}시리즈`;
  return (
    <ScaledStage>
      {u === "records" ? (
        <RecordsScreen
          highlightId={savedRecordId}
          onBack={() => {
            (setSavedRecordId(null), d("menu"));
          }}
        />
      ) : u === "menu" ? (
        <SetupScreen
          draft={o}
          onChange={s}
          onStart={v}
          onOpenRecords={() => d("records")}
        />
      ) : (
        <div className="range-console">
          <header className="range-header">
            <div className="range-brand">
              <svg
                width="30"
                height="30"
                viewBox="0 0 30 30"
                fill="none"
                aria-hidden="true"
              >
                <circle cx="15" cy="15" r="10" stroke="currentColor" />
                <circle cx="15" cy="15" r="4" stroke="currentColor" />
                <path d="M15 1v8m0 12v8M1 15h8m12 0h8" stroke="currentColor" />
              </svg>
              <div>
                <strong>ELECTRONIC TARGET</strong>
                <span>
                  {Rt.label}
                  {" · "}
                  {Oe.code}
                </span>
              </div>
            </div>
            <div className={`range-state ${m.phase}`}>
              <span />
              {G ? "END" : m.phase === "ready" ? "READY" : "LIVE"}
            </div>
            <div className="range-status-text">
              {Rt.zeroing
                ? m.phase === "ready"
                  ? "첫 착탄부터 탄착이 기록됩니다"
                  : G
                    ? "영점 사격 종료"
                    : `탄착 ${$t}발 기록 중`
                : sessionStatusText(m)}
            </div>
            <div className="header-controls">
              <div className="header-shot-count">
                <span>샷</span>
                <strong data-testid="shot-count">
                  {String($t).padStart(2, "0")}
                </strong>
                <small>
                  {"/ "}
                  {m.config.shots ?? "무제한"}
                </small>
              </div>
              {m.config.perShotSec !== null && (
                <Countdown
                  deadline={m.shotDeadline}
                  duration={G ? null : m.config.perShotSec * 1e3}
                  label="발당"
                />
              )}
              {m.config.totalSec !== null && (
                <Countdown
                  deadline={m.totalDeadline}
                  duration={G ? null : m.config.totalSec * 1e3}
                  label="전체"
                />
              )}
              <div className={`header-options ${locked ? "is-locked" : ""}`}>
                <button onClick={() => ct(!F)} aria-pressed={F}>
                  숫자
                </button>
                <button
                  onClick={() => {
                    const next = !o.sound;
                    s((qt) => ({
                      ...qt,
                      sound: next,
                    }));
                    next && playImpactSound();
                  }}
                  aria-pressed={o.sound}
                >
                  효과음
                </button>
              </div>
              {!Rt.zeroing && (
                <div
                  className={`voice-switch ${locked ? "is-locked" : ""}`}
                  aria-label="음성 선택"
                >
                  {["off", "male", "female"].map((it) => (
                    <button
                      key={it}
                      aria-pressed={o.voice === it}
                      onClick={() => {
                        (it === "off" && clearSpeech(),
                          s((qt) => ({
                            ...qt,
                            voice: it,
                          })));
                      }}
                    >
                      {it === "off" ? "무음" : it === "male" ? "남성" : "여성"}
                    </button>
                  ))}
                </div>
              )}
              <button
                className={`control-lock ${locked ? "is-locked" : ""}`}
                onClick={() => setLocked((v) => !v)}
                aria-pressed={!locked}
                title="표적 외 버튼 오작동 방지 잠금"
              >
                <span aria-hidden="true">{locked ? "🔒" : "🔓"}</span>
                <span>
                  <strong>{locked ? "조작 잠금" : "조작 가능"}</strong>
                  <small>{locked ? "눌러서 해제" : "착탄 시 자동 잠금"}</small>
                </span>
              </button>
            </div>
          </header>
          <main className="range-main">
            <section
              className={`target-column ${Rt.zeroing ? "is-zeroing" : ""}`}
              aria-label="전자 표적"
            >
              <div
                className="target-square flex items-center justify-center"
                data-real-size-mm={Rt.zeroing ? undefined : Rt.cardSize}
              >
                {Rt.zeroing ? (
                  <div className="zeroing-target-box">
                    <ShootingTarget
                      spec={Rt}
                      shots={Ht}
                      lastId={Qe?.id ?? null}
                      armed={isSessionOpen(m) && !Dt && !rt}
                      showShots={!marksOff}
                      numberField="index"
                      showNumbers={F}
                      onHit={B}
                    />
                  </div>
                ) : (
                  <div
                    style={{
                      width: realSizePx,
                      height: realSizePx,
                    }}
                  >
                    <ShootingTarget
                      spec={Rt}
                      shots={Ht}
                      lastId={Qe?.id ?? null}
                      armed={isSessionOpen(m) && !Dt && !rt}
                      showShots={!marksOff}
                      numberField={N === "series" ? "no" : "index"}
                      showNumbers={F}
                      onHit={B}
                    />
                  </div>
                )}
              </div>
              {!Rt.zeroing && (
                <TargetCaption
                  zeroing={false}
                  marksOff={marksOff}
                  scope={va}
                  hitCount={xt.hitCount}
                  voice={o.voice}
                />
              )}
            </section>
            {!Rt.zeroing && (
              <aside
                className={`series-column ${locked ? "is-locked" : ""}`}
                aria-label="시리즈 선택"
              >
                <SeriesStrip
                  spec={Rt}
                  series={Xe.list}
                  offset={Xe.offset}
                  activeIndex={N === "series" ? zt : -1}
                  onSelect={st}
                  onPrevious={() => st(zt - 1)}
                  onNext={() => st(zt + 1)}
                  canPrevious={zt > 0}
                  canNext={zt < seriesCount(m) - 1}
                />
              </aside>
            )}
            {Rt.zeroing ? (
              <aside className="zero-info-column" aria-label="영점 기록">
                <TargetCaption
                  zeroing
                  marksOff={marksOff}
                  scope={va}
                  hitCount={xt.hitCount}
                  voice={o.voice}
                />
                <div className={`record-wrap ${locked ? "is-locked" : ""}`}>
                  <RecordPanel
                    session={m}
                    spec={Rt}
                    last={Qe}
                    seriesIndex={zt}
                    shownStats={xt}
                    totalStats={ve}
                    view={N}
                    scopeLabel={va}
                    onView={R}
                    onSeries={st}
                    onShot={(it) => Y(it.id)}
                  />
                </div>
              </aside>
            ) : (
              <div className={`record-wrap ${locked ? "is-locked" : ""}`}>
                <RecordPanel
                  session={m}
                  spec={Rt}
                  last={Qe}
                  seriesIndex={zt}
                  shownStats={xt}
                  totalStats={ve}
                  view={N}
                  scopeLabel={va}
                  onView={R}
                  onSeries={st}
                  onShot={(it) => Y(it.id)}
                />
              </div>
            )}
          </main>
          <footer className={`range-footer ${locked ? "is-locked" : ""}`}>
            <FunctionButton
              label={m.phase === "ready" ? "사격 시작" : "샷 기록"}
              description={
                m.phase === "ready"
                  ? "첫 착탄 시 자동 시작"
                  : Rt.zeroing
                    ? "탄착 기록 중"
                    : "현재 시리즈로 돌아가기"
              }
              onClick={P}
              active={m.phase === "ready"}
            />
            <FunctionButton
              label="전체 탄착 보기"
              description={`누적 ${m.shots.length}발 전체 표시`}
              onClick={() => {
                (setMarksOff(false), R("all"));
              }}
              active={!marksOff && N !== "series"}
            />
            {!Rt.zeroing && (
              <FunctionButton
                label="현재 탄착 보기"
                description={`${zt + 1}시리즈 탄착만 표시`}
                onClick={() => {
                  (setMarksOff(false), R("series"));
                }}
                active={!marksOff && N === "series"}
              />
            )}
            <FunctionButton
              label="탄착 끄기"
              description="표적에서 탄착 숨기기"
              onClick={() => setMarksOff((it) => !it)}
              active={marksOff}
            />
            <FunctionButton
              label="게임 전체 리셋"
              description="모든 샷 · 타이머 초기화"
              onClick={() => dt("reset")}
            />
            <FunctionButton
              label={G ? "결과 보기" : "사격 종료"}
              description={G ? "완료된 결과 다시 확인" : "종료 후 결과 보기"}
              onClick={et}
              disabled={!G && $t === 0}
              active={G}
            />
            <FunctionButton
              label="메뉴"
              description="종목 · 사격 설정"
              onClick={U}
            />
          </footer>
        </div>
      )}
      {u === "range" && Dt && rt === null && (
        <ResultsSheet
          session={m}
          spec={Rt}
          stats={ve}
          voice={o.voice}
          onReview={$}
          onRestart={vt}
          onMenu={_}
          onSaveRecord={onSaveRecord}
        />
      )}
      {rt !== null && (
        <Dialog
          labelId="confirm-title"
          onClose={() => dt(null)}
          className="confirm-sheet"
        >
          <span className="eyebrow">SESSION CONTROL</span>
          <h2 id="confirm-title">
            {rt === "reset"
              ? "게임을 전체 리셋할까요?"
              : rt === "menu"
                ? "메뉴로 이동할까요?"
                : "사격을 종료할까요?"}
          </h2>
          <p>
            {rt === "reset"
              ? "모든 샷, 시리즈 점수, 타이머와 음성 대기열을 초기화합니다. 현재 종목과 사격 설정은 유지됩니다."
              : rt === "menu"
                ? "진행 중인 게임을 나가고 사격 설정 메뉴로 이동합니다."
                : `현재 ${$t}발까지의 기록으로 결과 화면을 엽니다.`}
          </p>
          <div className="flex justify-end gap-[10px] mt-[28px]">
            <button className="console-button" onClick={() => dt(null)}>
              취소
            </button>
            <button
              className="console-button primary"
              onClick={() => {
                rt === "reset"
                  ? vt()
                  : rt === "menu"
                    ? _()
                    : (I({
                        type: "finish",
                        now: Date.now(),
                      }),
                      dt(null));
              }}
            >
              {rt === "reset"
                ? "전체 리셋"
                : rt === "menu"
                  ? "메뉴로 이동"
                  : "종료하고 결과 보기"}
            </button>
          </div>
        </Dialog>
      )}
    </ScaledStage>
  );
}
